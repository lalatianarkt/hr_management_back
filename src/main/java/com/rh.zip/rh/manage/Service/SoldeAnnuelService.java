package com.rh.manage.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rh.manage.Model.Employe;
import com.rh.manage.Model.MouvementSolde;
import com.rh.manage.Model.RegleGestionConges;
import com.rh.manage.Model.SoldeAnnuel;
import com.rh.manage.Repository.SoldeAnnuelRepository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class SoldeAnnuelService {

    @Autowired
    CalculSoldeService calculSoldeService;

    @Autowired
    EmployeService employeService;

    @Autowired
    MouvementSoldeService mouvementSoldeService;

    @Autowired
    RegleGestionCongesService regleGestionCongesService;

    private final SoldeAnnuelRepository repository;

    public SoldeAnnuelService(SoldeAnnuelRepository repository) {
        this.repository = repository;
    }

    public List<SoldeAnnuel> getAllSolde() {
        return repository.findAll();
    }

    public Optional<SoldeAnnuel> getSoldeById(String id) {
        return repository.findById(id);
    }

    public List<SoldeAnnuel> getSoldeByEmploye(String idEmploye) {
        return repository.findByIdEmploye(idEmploye);
    }

    public SoldeAnnuel saveSolde(SoldeAnnuel solde) {
        return repository.save(solde);
    }

    public void deleteSolde(String id) {
        repository.deleteById(id);
    }

    @Transactional
    public List<SoldeAnnuel> clotureGlobale(int annee) {
        List<Employe> les_employes = employeService.getAll();
        List<SoldeAnnuel> soldesClotures = new ArrayList<>();
        
        for (Employe employe : les_employes) {
            try {
                System.out.println("idEmp : " + employe.getId());
                SoldeAnnuel soldeAnnuel = new SoldeAnnuel();
                soldeAnnuel.setIdEmploye(employe.getId());
                soldeAnnuel.setAnnee(annee);
                System.out.println("année : " + annee);
                soldeAnnuel.setDateCloture(LocalDate.now());
                
                if (!calculSoldeService.isEligible(employe)) {
                    BigDecimal soldeConge = calculSoldeService.calculSoldeCongeParAnciennete(employe);
                    System.out.println("soldeCongé an'io employé : " + soldeConge);
                    soldeAnnuel.setNbCongePris(0.0);
                    soldeAnnuel.setNbCongeRestant(soldeConge.doubleValue());
                    soldeAnnuel.setNbCongeTotal(soldeConge.doubleValue());
                } else {
                    Optional<MouvementSolde> dernierMouvementOpt = mouvementSoldeService
                            .getDernierMouvementSoldeParEmployeEtParAnnee(employe, annee);
                    
                    if (dernierMouvementOpt.isPresent()) {
                        MouvementSolde dernierMouvement = dernierMouvementOpt.get();
                        soldeAnnuel.setNbCongePris(dernierMouvement.getNbCongePris());
                        soldeAnnuel.setNbCongeRestant(dernierMouvement.getNbCongeRestant());
                        soldeAnnuel.setNbCongeTotal(dernierMouvement.getNbCongeTotal());
                    } else {
                        BigDecimal soldeConge = calculSoldeService.calculSoldeCongeParAnciennete(employe);
                        soldeAnnuel.setNbCongePris(0.0);
                        soldeAnnuel.setNbCongeRestant(soldeConge.doubleValue());
                        soldeAnnuel.setNbCongeTotal(soldeConge.doubleValue());
                    }
                }
                System.out.println("Nb de congé pris : " + soldeAnnuel.getNbCongePris());
                System.out.println("nombre de congé restant : " + soldeAnnuel.getNbCongeRestant());
                System.out.println("nb de congé total : " + soldeAnnuel.getNbCongeTotal());
                System.out.println("date cloture : " + soldeAnnuel.getDateCloture());
                
                soldeAnnuel.setStatutCloture(1);
                SoldeAnnuel saved = saveSolde(soldeAnnuel);
                soldesClotures.add(saved);

                //reporter les congés pour l'année prochaine
                reporterCongeAnnuel(employe, annee);
                
            } catch (Exception e) {
                System.out.println("erreur : " + e.getMessage());
                e.printStackTrace();
            }
        }
        
        return soldesClotures;
    }

    public SoldeAnnuel reporterCongeAnnuel(Employe employe, int annee){
       SoldeAnnuel nouveauSoldeAnnuel = new SoldeAnnuel();
       nouveauSoldeAnnuel.setAnnee(annee + 1);
       nouveauSoldeAnnuel.setDateCloture(LocalDate.now());
       nouveauSoldeAnnuel.setIdEmploye(employe.getId());
       nouveauSoldeAnnuel.setStatutCloture(0); //ouvert
       SoldeAnnuel soldeAnnuel = getSoldeByEmployeAndAnnee(employe.getId(), annee).get();
       double reste = soldeAnnuel.getNbCongeRestant();
       RegleGestionConges regleGestionConges = regleGestionCongesService.getDerniereRegleGestionCongesParStatutActive();
       double limiteReport = regleGestionConges.getLimiteReportAnnuel();
       if(reste - limiteReport > 0){
         nouveauSoldeAnnuel.setNbCongePris(0.0);
         nouveauSoldeAnnuel.setNbCongeRestant(limiteReport);
         nouveauSoldeAnnuel.setNbCongeTotal(limiteReport);
       } else if(reste - limiteReport < 0){
         nouveauSoldeAnnuel.setNbCongePris(0.0);
         nouveauSoldeAnnuel.setNbCongeRestant(reste);
         nouveauSoldeAnnuel.setNbCongeTotal(reste);
       } else{
         nouveauSoldeAnnuel.setNbCongePris(0.0);
         nouveauSoldeAnnuel.setNbCongeRestant(0.0);
         nouveauSoldeAnnuel.setNbCongeTotal(0.0);
       }
       repository.save(nouveauSoldeAnnuel);
       return nouveauSoldeAnnuel;
    }

    public List<SoldeAnnuel> getSoldeByAnnee(Integer annee) {
        System.out.println("🔍 Service: Recherche des soldes pour l'année " + annee);
        
        List<SoldeAnnuel> result = repository.findByAnnee(annee);
        
        System.out.println("📊 Service: " + (result != null ? result.size() : 0) + 
                          " soldes trouvés pour l'année " + annee);
        
        return result;
    }

    // Méthode pour récupérer par employé ET année
    public Optional<SoldeAnnuel> getSoldeByEmployeAndAnnee(String idEmploye, Integer annee) {
        return repository.findByIdEmployeAndAnnee(idEmploye, annee);
    }

    // Méthode pour récupérer les années disponibles
    public List<Integer> getAnneesDisponibles() {
        List<Integer> annees = repository.findDistinctAnnees();
        System.out.println("📅 Service: " + annees.size() + " années disponibles trouvées");
        return annees;
    }

    // Méthode avec tri
    public List<SoldeAnnuel> getSoldeByAnneeOrdered(Integer annee) {
        return repository.findByAnneeOrderByEmploye(annee);
    }
}
