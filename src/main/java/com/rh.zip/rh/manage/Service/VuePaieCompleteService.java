package com.rh.manage.Service;

import com.rh.manage.Model.VuePaieComplete;
import com.rh.manage.Repository.VuePaieCompleteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Service
@Transactional(readOnly = true)
public class VuePaieCompleteService {
    
    @Autowired
    private VuePaieCompleteRepository repository;
    
    // Récupérer toutes les données
    public List<VuePaieComplete> getAll() {
        return repository.findAll();
    }
    
    // Récupérer par ID employé
    public List<VuePaieComplete> getByIdEmploye(String idEmploye) {
        return repository.findByIdEmploye(idEmploye);
    }
    
    // Récupérer par matricule
    public List<VuePaieComplete> getByMatricule(String matricule) {
        return repository.findByMatricule(matricule);
    }
    
    // Récupérer par département
    public List<VuePaieComplete> getByDepartement(String departement) {
        return repository.findByDepartement(departement);
    }
    
    // Récupérer par statut de clôture
    public List<VuePaieComplete> getByStatutCloture(Integer statutCloture) {
        return repository.findByStatutCloture(statutCloture);
    }
    
    // Récupérer par période
    public List<VuePaieComplete> getByPeriode(LocalDate dateDebut, LocalDate dateFin) {
        return repository.findByDateDebutPeriodeBetween(dateDebut, dateFin);
    }
    
    // Récupérer par mois et année
    public List<VuePaieComplete> getByMoisAnnee(Integer mois, Integer annee) {
        return repository.findByMoisAndAnnee(mois, annee);
    }
    
    // Recherche avec critères multiples
    public List<VuePaieComplete> searchByCriteria(String departement, Integer statutCloture, 
                                                  String categorieSalaire, LocalDate dateDebut, 
                                                  LocalDate dateFin) {
        return repository.findByCriteria(departement, statutCloture, categorieSalaire, dateDebut, dateFin);
    }
    
    // Statistiques par département
    public Map<String, Object> getStatsDepartement() {
        List<Object[]> results = repository.getStatsByDepartement();
        Map<String, Object> stats = new HashMap<>();
        
        List<Map<String, Object>> departementsStats = new ArrayList<>();
        for (Object[] row : results) {
            Map<String, Object> deptStat = new HashMap<>();
            deptStat.put("departement", row[0]);
            deptStat.put("nombrePaies", row[1]);
            deptStat.put("masseSalarialeBrute", row[2]);
            deptStat.put("salaireMoyen", row[3]);
            departementsStats.add(deptStat);
        }
        
        stats.put("departements", departementsStats);
        return stats;
    }
    
    // Statistiques par mois/année
    public Map<String, Object> getStatsMoisAnnee() {
        List<Object[]> results = repository.getStatsByMoisAnnee();
        Map<String, Object> stats = new HashMap<>();
        
        List<Map<String, Object>> periodesStats = new ArrayList<>();
        for (Object[] row : results) {
            Map<String, Object> periodeStat = new HashMap<>();
            periodeStat.put("annee", row[0]);
            periodeStat.put("mois", row[1]);
            periodeStat.put("nombrePaies", row[2]);
            periodeStat.put("masseSalarialeBrute", row[3]);
            periodeStat.put("masseSalarialeNette", row[4]);
            periodesStats.add(periodeStat);
        }
        
        stats.put("periodes", periodesStats);
        return stats;
    }
    
    // Obtenir les périodes distinctes
    public List<LocalDate> getPeriodesDistinctes() {
        return repository.findDistinctPeriodes();
    }
    
    // Obtenir les départements distincts
    public List<String> getDepartementsDistincts() {
        return repository.findDistinctDepartements();
    }
    
    // Obtenir les catégories de salaire distinctes
    public List<String> getCategoriesSalaireDistinctes() {
        return repository.findDistinctCategoriesSalaire();
    }
    
    // Calculer les totaux globaux
    public Map<String, BigDecimal> getTotauxGlobaux(LocalDate dateDebut, LocalDate dateFin) {
        List<VuePaieComplete> paies = repository.findByDateDebutPeriodeBetween(dateDebut, dateFin);
        
        BigDecimal totalSalaireBrut = BigDecimal.ZERO;
        BigDecimal totalSalaireNet = BigDecimal.ZERO;
        BigDecimal totalRetenues = BigDecimal.ZERO;
        BigDecimal totalCotisations = BigDecimal.ZERO;
        
        for (VuePaieComplete paie : paies) {
            totalSalaireBrut = totalSalaireBrut.add(paie.getSalaireBrut() != null ? paie.getSalaireBrut() : BigDecimal.ZERO);
            totalSalaireNet = totalSalaireNet.add(paie.getSalaireNet() != null ? paie.getSalaireNet() : BigDecimal.ZERO);
            totalRetenues = totalRetenues.add(paie.getTotalRetenue() != null ? paie.getTotalRetenue() : BigDecimal.ZERO);
            totalCotisations = totalCotisations.add(paie.getTotalCotisations() != null ? paie.getTotalCotisations() : BigDecimal.ZERO);
        }
        
        Map<String, BigDecimal> totaux = new HashMap<>();
        totaux.put("totalSalaireBrut", totalSalaireBrut);
        totaux.put("totalSalaireNet", totalSalaireNet);
        totaux.put("totalRetenues", totalRetenues);
        totaux.put("totalCotisations", totalCotisations);
        
        return totaux;
    }
    
    // Recherche avancée avec pagination (méthode d'exemple)
    public List<VuePaieComplete> searchAvancee(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getAll();
        }
        
        String term = searchTerm.toLowerCase().trim();
        List<VuePaieComplete> result = new ArrayList<>();
        
        // Recherche dans différents champs
        result.addAll(repository.findByNomContainingIgnoreCase(term));
        result.addAll(repository.findByPrenomContainingIgnoreCase(term));
        result.addAll(repository.findByNomCompletContainingIgnoreCase(term));
        result.addAll(repository.findByMatricule(term));
        result.addAll(repository.findByDepartement(term));
        result.addAll(repository.findByFonction(term));
        
        // Éliminer les doublons
        Set<String> ids = new HashSet<>();
        List<VuePaieComplete> uniqueResults = new ArrayList<>();
        for (VuePaieComplete paie : result) {
            if (ids.add(paie.getIdEmploye() + "_" + paie.getPaieId())) {
                uniqueResults.add(paie);
            }
        }
        
        return uniqueResults;
    }

    public List<VuePaieComplete> findByDepartement(String departement) {
        return repository.findByDepartementAndStatutCloture(departement, 0);
    } 
}
