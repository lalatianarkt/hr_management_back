package com.rh.manage.Service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rh.manage.Model.Token;
import com.rh.manage.Model.User;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    UserService userService;

    @Autowired
    TokenService tokenService;

    public String sendTokenEmail(String recipientEmail) {
        // Générer un token aléatoire
        String token = UUID.randomUUID().toString();

        // Créer le message
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("rakotovaolalatiana2@gmail.com"); // votre email
        message.setTo(recipientEmail);
        message.setSubject("Validation de votre compte");
        message.setText("Voici votre code de validation : " + token + "\nCe code est valide pour 30 secondes.");

        // Envoyer l'email
        mailSender.send(message);
        return token;
    }

    @Transactional
    public String reSendToken(String recipientEmail){
        String token = sendTokenEmail(recipientEmail);
        User user = userService.findByEmail(recipientEmail).get();
        // Token dernierToken = tokenService.getDernierTokenActiveParUser(user);
        // dernierToken.setIsActive(0);
        // tokenService.update(dernierToken);
            Token newToken = new Token();
            LocalDateTime now = LocalDateTime.now();
            newToken.setExpiresAt(now.plusSeconds(120));
            newToken.setCreatedAt(now);
            newToken.setIsActive(1);
            newToken.setTokenGenere(token);
            newToken.setType("inscription");
            newToken.setUser(user);
            tokenService.save(newToken);
            System.out.println(token);
        return token;
    }
}
