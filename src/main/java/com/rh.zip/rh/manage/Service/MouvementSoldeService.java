package com.rh.manage.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rh.manage.Model.Employe;
import com.rh.manage.Model.MouvementSolde;
import com.rh.manage.Model.TypeEnumConge;
import com.rh.manage.Repository.MouvementSoldeRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class MouvementSoldeService {

    @Autowired
    EmployeService employeService;

    private final MouvementSoldeRepository repository;

    public MouvementSoldeService(MouvementSoldeRepository repository) {
        this.repository = repository;
    }

    public List<MouvementSolde> getAllMouvements() {
        return repository.findAll();
    }

    public Optional<MouvementSolde> getMouvementById(int id) {
        return repository.findById(id);
    }

    public List<MouvementSolde> getMouvementsByEmploye(Employe employe) {
        return repository.findByEmploye(employe);
    }

    public List<MouvementSolde> getMouvementsByType(TypeEnumConge typeMouvement) {
        return repository.findByTypeMouvement(typeMouvement);
    }

    public MouvementSolde saveMouvement(MouvementSolde mouvement) {
        return repository.save(mouvement);
    }

    public void deleteMouvement(int id) {
        repository.deleteById(id);
    }

    public Optional<MouvementSolde> getDernierMouvementSoldeParEmployeEtParAnnee(Employe employe, int annee){
        return repository.findFirstByEmployeAndStatutOrderByMoisDescCreatedAtDesc(employe, annee);
    } 

    public Optional<MouvementSolde> findByEmployeAndStatutOrderByCreatedAtDesc(Employe employe){
        return repository.findFirstByEmployeAndStatutOrderByMoisDescCreatedAtDesc(employe, 1);
    }  

    // ✅ CHAQUE MOIS (cron job automatique)
    
    
    // AUJOURD'HUI À 11H HEURE MADAGASCAR
    // @Scheduled(cron = "0 05 16 * * *", zone = "Indian/Antananarivo") Ceci c pour 16h 15
    // @Scheduled(cron = "0 0 1 1 * *") // Le 1er de chaque mois à minuit 
    @Scheduled(cron = "0 30 15 * * *")  // 15:30 tous les jours
    // @Transactional 
    public void ajouterCongesMensuel() {
        System.out.println("💰 Ajout des 2.5 jours/mois...");

        List<Employe> employesActifs = employeService.getEmployesActifs();

        for (Employe employe : employesActifs) {
            try {
                // Création du nouveau mouvement
                MouvementSolde nouveauMouvement = new MouvementSolde();
                // nouveauMouvement.setIdEmploye(employe.getId());
                nouveauMouvement.setEmploye(employe);
                nouveauMouvement.setAnnee(2026); // ou LocalDate.now().getYear()
                nouveauMouvement.setMois(1); // ou LocalDate.now().getMonthValue()
                nouveauMouvement.setCommentaire("Acquisition mensuelle 2.5 jours");
                nouveauMouvement.setTypeMouvement(TypeEnumConge.ACQUISITION);
                nouveauMouvement.setStatut(1); // si applicable

                // Récupérer le dernier mouvement s'il existe
                Optional<MouvementSolde> optDernierMouvement =
                        findByEmployeAndStatutOrderByCreatedAtDesc(employe);

                if (optDernierMouvement.isPresent()) {
                    MouvementSolde dernierMouvement = optDernierMouvement.get();
                    double ancienSolde = dernierMouvement.getNbCongeRestant();
                    double nouveauSolde = ancienSolde + 2.5;
                    nouveauMouvement.setNbCongeTotal(dernierMouvement.getNbCongeTotal() + 2.5);
                    nouveauMouvement.setNbCongeRestant(nouveauSolde);
                    nouveauMouvement.setNbCongePris(dernierMouvement.getNbCongePris());
                    System.out.println("💰 Mise à jour pour " + employe.getId() + " - Nouveau solde : " + nouveauSolde);
                } else {
                    // Aucun mouvement précédent, initialisation
                    nouveauMouvement.setNbCongeTotal(2.5);
                    nouveauMouvement.setNbCongeRestant(2.5);
                    nouveauMouvement.setNbCongePris(0.0);
                    System.out.println("⚠️ Aucun mouvement précédent, initialisation pour " + employe.getId());
                }

                repository.save(nouveauMouvement);

            } catch (Exception e) {
                System.out.println("❌ Erreur pour l'employé " + employe.getId() + ": " + e.getMessage());
                e.printStackTrace();
            }
        }

        System.out.println("💰 Ajout des 2.5 jours/mois terminé.");
    }

    public List<MouvementSolde> getMouvementsPrisByEmploye(Employe employe) {
        return repository.findByEmployeAndTypeMouvementOrderByCreatedAtAsc(
                employe,
                TypeEnumConge.PRISE
        ); 
    }

    public MouvementSolde getDernierMouvementParEmploye(Employe employe){
        return repository.findFirstByEmployeAndStatutOrderByMoisDescCreatedAtDesc(employe, 1).get();
    } 
}
