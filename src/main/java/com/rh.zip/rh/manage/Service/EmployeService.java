package com.rh.manage.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rh.manage.Dto.EmployeDTO;
import com.rh.manage.Dto.EmployeDetailsDTO;
import com.rh.manage.Dto.EmployeInfosDTO;
import com.rh.manage.Enum.ModeCalcul;
import com.rh.manage.Model.Departement;
import com.rh.manage.Model.EmergencyContact;
import com.rh.manage.Model.Employe;
import com.rh.manage.Model.EtatCivil;
import com.rh.manage.Model.InfosAdministratives;
import com.rh.manage.Model.InfosProfessionnelles;
import com.rh.manage.Model.Manager;
import com.rh.manage.Model.Nationalite;
import com.rh.manage.Model.Poste;
import com.rh.manage.Model.PosteEmploye;
import com.rh.manage.Model.Sexe;
import com.rh.manage.Repository.EmployeRepository;
import com.rh.manage.Repository.InfosProfessionnellesRepository;

import java.sql.Connection;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EmployeService {

    @Autowired
    private InfosProfessionnellesRepository infosProfessionnellesRepository;

    @Autowired
    InfosProfessionnellesService infosProfessionnellesService;

    @Autowired
    EmployeRepository employeRepository;

    @Autowired
    InfosAdministrativesService infosAdministrativesService;

    @Autowired 
    EmergencyContactService emergencyContactService;

    @Autowired
    NationaliteService nationaliteService;

    @Autowired
    SexeService sexeService;

    @Autowired
    ManagerService managerService;

    // ✅ Récupérer tous les employés
    public List<Employe> getAll() {
        return employeRepository.findAll();
    }

    // ✅ Récupérer par ID
    public Optional<Employe> getById(String id) {
        return employeRepository.findById(id);
    }

    // ✅ Récupérer par email
    public Optional<Employe> getByEmail(String email) {
        return employeRepository.findByEmail(email);
    }

    // ✅ Créer un employé
    public Employe create(Employe employe) {
        return employeRepository.save(employe);
    }

    // ✅ Mettre à jour un employé
    public Employe update(Employe employe) {
        return employeRepository.save(employe);
    }

    // ✅ Supprimer un employé
    public void delete(String id) {
        employeRepository.deleteById(id);

    }

    public List<Employe> findAllEmployeesActived(){
        return employeRepository.findAllEmployeesByStatusSorted(0);
    }

    // Version paginée avec paramètres
    public Page<EmployeInfosDTO> getAllEmployesWithInfos(
        int page, 
        int size, 
        String sortBy, 
        String direction
    ) {
        // Créer l'objet Pageable
        Sort sort = Sort.by(sortBy);
        
        if (direction.equalsIgnoreCase("desc")) {
            sort = sort.descending();
        } else {
            sort = sort.ascending();
        }
        
        Pageable pageable = PageRequest.of(page, size, sort);
        
        // Récupérer la page d'employés
        Page<Employe> employePage = employeRepository.findAllActiveEmployeesSorted(pageable);
        
        // Transformer chaque employé en DTO
        List<EmployeInfosDTO> dtos = employePage.getContent().stream()
            .map(employe -> {
                List<InfosProfessionnelles> infos = 
                    infosProfessionnellesService.getInfoProfessionnelleByEmployeId(employe.getId());
                return new EmployeInfosDTO(employe, infos);
            })
            .collect(Collectors.toList());
        
        // Retourner une Page de DTOs
        return new PageImpl<>(dtos, pageable, employePage.getTotalElements());
    }

    public List<EmployeInfosDTO> getAllEmployesWithInfos() {

        List<Employe> employes = employeRepository.findAllEmployeesByStatusSorted(0);
        // System.out.println("long : " + employes.size());

        List<EmployeInfosDTO> result = new ArrayList<>();

        for (Employe employe : employes) {

            List<InfosProfessionnelles> optInfos =
                    infosProfessionnellesService.getInfoProfessionnelleByEmployeId(employe.getId());

            // InfosProfessionnelles infosPro = optInfos.orElse(null);

            // if (infosPro == null) {
            //     // System.out.println("⚠️ Pas d'infos pro pour : " + employe.getId());
            // } else {
            //     // System.out.println("infosPro : " + infosPro.getEmploye().getId());
            // }

            EmployeInfosDTO dto = new EmployeInfosDTO(employe, optInfos);
            result.add(dto);
        }

        return result;
    }

    public EmployeInfosDTO getEmployeWithInfosById(String id) {
        Optional<Employe> employeOpt = employeRepository.findByIdAndStatut(id, 0);
        if (employeOpt.isPresent()) {
            Employe employe = employeOpt.get();
            List<InfosProfessionnelles> infosProOpt = infosProfessionnellesRepository.findByEmployeIdAndStatut(id);
            
            EmployeInfosDTO dto = new EmployeInfosDTO();
            dto.setEmploye(employe);
            dto.setInfosProfessionnelles(infosProOpt);
            
            return dto;
        }
        return null;
    }

    public void validation_formulaire_insertion(EmployeDTO employeDTO) throws Exception {
        StringBuilder errors = new StringBuilder();

        // if(employeDTO.getInfosAdministratives() != null){
        //     InfosAdministratives infosAdministratives = employeDTO.getInfosAdministratives();

        //     if(infosAdministratives.getCin().length() != 12){
        //         errors.append("Le nombre de chiffres dans cin doit contenir obligatoirement 12 chiffres. \n");
        //     }
        // }
        
        // Validation de l'employé
        if (employeDTO.getEmploye() != null) {
            // EmployeDetailsDTO employe = employeDTO.getEmployeDetailsDTO();
            Employe employe = employeDTO.getEmploye();

            if(employeDTO.getNationalite() == null){
                errors.append("La nationalité de l'employé est obligatoire. Veuillez remplir ce champ");
            }
            
            if (employe.getNom() == null || employe.getNom().trim().isEmpty()) {
                errors.append("Le nom de l'employé est obligatoire.\n");
            } else if (employe.getNom().length() > 100) {
                errors.append("Le nom de l'employé ne doit pas dépasser 100 caractères.\n");
            } 
            
            if (employe.getPrenom() == null || employe.getPrenom().trim().isEmpty()) {
                errors.append("Le prénom de l'employé est obligatoire.\n");
            } else if (employe.getPrenom().length() > 250) {
                errors.append("Le prénom de l'employé ne doit pas dépasser 250 caractères.\n");
            }
            
            if (employe.getDateNaissance() == null) {
                errors.append("La date de naissance est obligatoire.\n");
            } else if (employe.getDateNaissance().isAfter(java.time.LocalDate.now())) {
                errors.append("La date de naissance ne peut pas être dans le futur.\n");
            }
            
            if (employe.getTelephone() == null || employe.getTelephone().trim().isEmpty()) {
                errors.append("Le téléphone de l'employé est obligatoire.\n");
            } else if (employe.getTelephone().length() > 12) {
                errors.append("Le téléphone de l'employé ne doit pas dépasser 12 caractères.\n");
            }
            
            if (employe.getEmail() == null || employe.getEmail().trim().isEmpty()) {
                errors.append("L'email de l'employé est obligatoire.\n");
            } else if (employe.getEmail().length() > 100) {
                errors.append("L'email de l'employé ne doit pas dépasser 100 caractères.\n");
            } else if (!isValidEmail(employe.getEmail())) {
                errors.append("L'email de l'employé n'est pas valide.\n");
            }
            
            if (employe.getAdresse() == null || employe.getAdresse().trim().isEmpty()) {
                errors.append("L'adresse de l'employé est obligatoire.\n");
            } else if (employe.getAdresse().length() > 255) {
                errors.append("L'adresse de l'employé ne doit pas dépasser 255 caractères.\n");
            }
            
            if (employe.getLieuNaissance() == null || employe.getLieuNaissance().trim().isEmpty()) {
                errors.append("Le lieu de naissance est obligatoire.\n");
            }

            if (employeDTO.getEmploye().getCin() == null || employeDTO.getEmploye().getCin().trim().isEmpty()) {
            errors.append("Le CIN est obligatoire.\n");
            }
            
            if (employeDTO.getEmploye().getNbEnfants() < 0) {
                errors.append("Le nombre d'enfants ne peut pas être négatif.\n");
            }

            if(employeDTO.getEmploye().getEtatCivil() == null){
                errors.append("La situation familiale est obligatoire.\n");
            }
        } else {
            errors.append("Les informations de l'employé sont obligatoires.\n");
        }
        
        // Validation du contact d'urgence
        if (employeDTO.getEmergencyContact() != null) {
            EmergencyContact emergencyContact = employeDTO.getEmergencyContact();
            
            if (emergencyContact.getNom() == null || emergencyContact.getNom().trim().isEmpty()) {
                errors.append("Le nom du contact d'urgence est obligatoire.\n");
            } else if (emergencyContact.getNom().length() > 250) {
                errors.append("Le nom du contact d'urgence ne doit pas dépasser 250 caractères.\n");
            }
            
            if (emergencyContact.getContact() == null || emergencyContact.getContact().trim().isEmpty()) {
                errors.append("Le contact d'urgence est obligatoire.\n");
            } else if (emergencyContact.getContact().length() > 12 && emergencyContact.getContact().length() < 0) {
                errors.append("Le contact d'urgence doit contenir exactement 12 caractères.\n");
            } else if (!emergencyContact.getContact().matches("\\d{10}")) {
                errors.append("Le contact d'urgence doit contenir uniquement des chiffres.\n");
            }
            
            if (emergencyContact.getEmail() != null && !emergencyContact.getEmail().trim().isEmpty()) {
                if (emergencyContact.getEmail().length() > 100) {
                    errors.append("L'email du contact d'urgence ne doit pas dépasser 100 caractères.\n");
                } else if (!isValidEmail(emergencyContact.getEmail())) {
                    errors.append("L'email du contact d'urgence n'est pas valide.\n");
                }
            }
            
            if (emergencyContact.getAdresse() != null && emergencyContact.getAdresse().length() > 255) {
                errors.append("L'adresse du contact d'urgence ne doit pas dépasser 255 caractères.\n");
            }
        } else {
            errors.append("Le contact d'urgence est obligatoire.\n");
        }
        
        // Validation des informations professionnelles
        if (employeDTO.getInfosProfessionnelles().size() != 0) {
            List<InfosProfessionnelles> InfosProfessionnelles = employeDTO.getInfosProfessionnelles();
            for (InfosProfessionnelles infosPro : InfosProfessionnelles) {
                if (infosPro.getDateEmbauche() == null) {
                    errors.append("La date d'embauche est obligatoire.\n");
                } else if (infosPro.getDateEmbauche().isAfter(java.time.LocalDate.now())) {
                    errors.append("La date d'embauche ne peut pas être dans le futur.\n");
                }
                
                if (infosPro.getPoste() == null || infosPro.getPoste().getId() == null) {
                    errors.append("Le poste est obligatoire.\n");
                }
                
                if (infosPro.getTypeContrat() == null || infosPro.getTypeContrat().getId() == null) {
                    errors.append("Le type de contrat est obligatoire.\n");
                }
            }
        } else {
            errors.append("Les informations professionnelles sont obligatoires.\n");
        }
        // Validation du sexe et nationalité
        if (employeDTO.getSexe() == null || employeDTO.getSexe().getId() == null) {
            errors.append("Le sexe est obligatoire.\n");
        }
        
        if (errors.length() > 0) {
            throw new IllegalArgumentException("Erreurs de validation :\n" + errors.toString());
        }
    }

    // Méthode utilitaire pour valider les emails
    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email != null && email.matches(emailRegex);
    }

    @Transactional
    public Employe insertionIntegraleEmploye(EmployeDTO employeDTO) throws Exception {
        try {
            // 1. Validation du formulaire
            validation_formulaire_insertion(employeDTO);
            Employe employe = employeDTO.getEmploye();


            EmergencyContact emergencyContact = emergencyContactService.create(employeDTO.getEmergencyContact());
            Nationalite nationalite = nationaliteService.getNationaliteById(employeDTO.getNationalite().getId()).get();
            Sexe sexe = sexeService.getSexeById(employeDTO.getSexe().getId()); 
            employe.setEmergencyContact(emergencyContact);
            // employe.setCreatedAt(LocalDateTime.now());
            employe.setNationalite(nationalite);
            employe.setSexe(sexe);

            // Sauvegarde finale de l'employé
            employe = create(employe);
            
            employeDTO.setEmploye(employe);// 
            System.out.println("idEmp : " + employe.getId());// historiquePosteService.save(employeDTO.getHistoriquePoste());
            
            Employe emp_inserted = getById(employeDTO.getEmploye().getId()).get();
            
            List<InfosProfessionnelles> infosPros = employeDTO.getInfosProfessionnelles();
            Manager manager = managerService.findManagerActuelByDepartement(infosPros.get(0).getDepartement().getId());
            for (InfosProfessionnelles infosPro : infosPros) {
                infosPro.setEmploye(emp_inserted);
                InfosProfessionnelles newInfos = new InfosProfessionnelles();
                newInfos.setEmploye(infosPro.getEmploye());
                newInfos.setTypeContrat(infosPro.getTypeContrat());
                newInfos.setSalaireBase(infosPro.getSalaireBase());
                newInfos.setDateDebutAssignationPoste(infosPro.getDateDebutAssignationPoste());
                newInfos.setDateFinAssignationPoste(infosPro.getDateFinAssignationPoste());
                newInfos.setMatricule(infosPro.getMatricule());
                newInfos.setDepartement(infosPro.getDepartement());
                // Manager managerActuel = managerService.findManagerActuelByDepartement();
                if(infosPros.size() > 1){
                    if(infosPro.getDateDebutAssignationPoste().isEqual(infosPros.get(0).getDateDebutAssignationPoste())){
                        newInfos.setStatut(1); 
                    }
                }                
                
                if(manager != null){
                    System.out.println();
                    newInfos.setManager(manager);
                } 
                newInfos.setDateEmbauche(infosPro.getDateEmbauche());
                newInfos.setDateDebutAssignationPoste(infosPro.getDateDebutAssignationPoste());
                newInfos.setPoste(infosPro.getPoste());

                // System.out.println("infoPro : "+ infosPro.getDepartement().getId());
                System.out.println("emp dans pro : " + infosPro.getEmploye().getId());
                // infosPro.setEmploye(employe); 
                infosPro = infosProfessionnellesService.create(newInfos); 

                // ✅ DÉBOGUAGE COMPLET
                System.out.println("=== DÉBOGUAGE RELATIONS INFO_PRO ===");
                // System.out.println("Departement: " + infosPro.getDepartement());
                // System.out.println("Departement ID: " + (infosPro.getDepartement() != null ? infosPro.getDepartement().getId() : "null"));
                System.out.println("Poste: " + infosPro.getPoste());
                System.out.println("Poste ID: " + (infosPro.getPoste() != null ? infosPro.getPoste().getId() : "null"));
                System.out.println("TypeContrat: " + infosPro.getTypeContrat());
                System.out.println("TypeContrat ID: " + (infosPro.getTypeContrat() != null ? infosPro.getTypeContrat().getId() : "null"));
                System.out.println("Employe: " + infosPro.getEmploye());
                System.out.println("Employe ID: " + (infosPro.getEmploye() != null ? infosPro.getEmploye().getId() : "null"));
                // System.out.println("Manager: " + infosPro.getManager());
                System.out.println("=====================================");
            }
            return employe;
        } catch (Exception e) {
            // Log détaillé de l'erreur
            System.err.println("Erreur lors de l'insertion intégrale de l'employé : " + e.getMessage());
            e.printStackTrace();
            // Relancer l'exception pour rollback
            throw e;
        }
    } 

    // Récupérer tous les employés actifs (statut = 0)
    public List<Employe> getEmployesActifs() {
        return employeRepository.findByStatut(0);
    }
    
    // Récupérer un employé actif par ID
    public Optional<Employe> getEmployeActifById(String id) {
        return employeRepository.findByIdAndStatut(id, 0);
        // return Optional.ofNullable(employe);
    }
    
    // Récupérer les infos professionnelles avec statut = 0 d'un employé
    public List<InfosProfessionnelles> getInfosProfessionnellesByEmployeId(String employeId) {
        return infosProfessionnellesRepository.findByEmployeIdAndStatut(employeId);
    } 
    
    // Récupérer la dernière info professionnelle avec statut = 0 d'un employé
    public Optional<InfosProfessionnelles> getDerniereInfoProfessionnelleByEmployeId(String employeId) {
        List<InfosProfessionnelles> infos = infosProfessionnellesRepository.findLatestByEmployeIdAndStatut(employeId);
        return infos.isEmpty() ? Optional.empty() : Optional.of(infos.get(0));
    }
    
    // Récupérer une info professionnelle avec statut = 0 d'un employé
    public List<InfosProfessionnelles> getInfoProfessionnelleByEmployeId(String employeId) {
        return infosProfessionnellesRepository.findByEmployeIdAndStatut(employeId);
    }
    
    // Vérifier si un employé a des infos professionnelles avec statut = 0
    // public boolean employeAvecInfosProfessionnelles(String employeId) {
    //     List<InfosProfessionnelles> infos = infosProfessionnellesRepository.findByEmployeIdAndStatut(employeId, 0);
    //     return !infos.isEmpty();
    // } 

    public Employe update_emp(Employe employe, String id) {
        try {

            System.out.println("tafiditra ato e ++++++++++++++++");
            // Vérifier si l'employé existe
            Employe emp_to_update = getById(id)
                .orElseThrow(() -> new RuntimeException("Employé non trouvé avec l'ID: " + id));
            
            System.out.println("employe : "+ emp_to_update.getId());    
            emp_to_update.setNom(employe.getNom());
            emp_to_update.setPrenom(employe.getPrenom());
            
            EtatCivil etatCivil = employe.getEtatCivil();
            if (etatCivil == EtatCivil.CELIBATAIRE) {
                emp_to_update.setEtatCivil(EtatCivil.CELIBATAIRE);

            } else if (etatCivil == EtatCivil.MARIE) {
                emp_to_update.setEtatCivil(EtatCivil.MARIE);

            } else if (etatCivil == EtatCivil.DIVORCE) {
                emp_to_update.setEtatCivil(EtatCivil.DIVORCE);

            } else if (etatCivil == EtatCivil.VEUF) {
                emp_to_update.setEtatCivil(EtatCivil.VEUF);
            }

            emp_to_update.setDateNaissance(employe.getDateNaissance());
            emp_to_update.setLieuNaissance(employe.getLieuNaissance());
            emp_to_update.setTelephone(employe.getTelephone());
            emp_to_update.setEmail(employe.getEmail());
            emp_to_update.setAdresse(employe.getAdresse());
            emp_to_update.setNomMere(employe.getNomMere());
            emp_to_update.setNomPere(employe.getNomPere());
            emp_to_update.setNumCnaps(employe.getNumCnaps());

            System.out.println("eto mihitsy");
            
            // Sauvegarder et retourner
            Employe emp_updated = update(emp_to_update);
            return emp_updated;
            
        } catch (RuntimeException e) {
            // Relancer les exceptions métier (employé non trouvé)
            throw e;
        } catch (Exception e) {
            // Logger l'erreur technique
            System.out.println("Erreur technique lors de la modification de l'employé " + id + ": " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Erreur technique lors de la modification de l'employé", e);
        }
    }

//     @Transactional
// public void insertionIntegraleEmploye(EmployeDTO employeDTO) throws Exception {
//     try {
//         // ... code existant jusqu'à la création de l'employé ...
//         System.out.println("ato1");
//         Employe emp_inserted = getById(employeDTO.getEmploye().getId()).get();
//         System.out.println("ato2");
//         InfosProfessionnelles infosPro = employeDTO.getInfosProfessionnelles();

//         // ✅ GESTION CORRECTE DU MANAGER
//         Manager managerPersiste = null;
        
//         if (infosPro.getManager() != null) {
//             System.out.println("ato");
//             // CAS 1: Manager a un ID → vérifier s'il existe en base
//             if (infosPro.getManager().getId() != null) {
//                 Optional<Manager> existingManager = managerService.getManagerById(infosPro.getManager().getId());
//                 if (existingManager.isPresent()) {
//                     managerPersiste = existingManager.get(); // ✅ Manager existant
//                     System.out.println("✅ Manager existant assigné: " + managerPersiste.getId());
//                 } else {
//                     System.out.println("⚠️ Manager avec ID non trouvé, mis à null");
//                     managerPersiste = null;
//                 }
//             } 
//             // CAS 2: Manager sans ID → nouvel objet non persisté → ERREUR POTENTIELLE
//             else {
//                 System.out.println("❌ Manager sans ID - objet non persisté, mis à null");
//                 managerPersiste = null;
//             }
//         }
//         // CAS 3: Manager est null → aucun problème
//         else {
//             System.out.println("✅ Aucun manager assigné");
//             managerPersiste = null;
//         }

//         // ✅ CRÉATION DE L'INFO PRO
//         InfosProfessionnelles newInfos = new InfosProfessionnelles();
//         newInfos.setEmploye(emp_inserted);
//         newInfos.setDepartement(infosPro.getDepartement());
//         newInfos.setTypeContrat(infosPro.getTypeContrat());
//         newInfos.setPoste(infosPro.getPoste());
//         newInfos.setDateEmbauche(infosPro.getDateEmbauche());
//         newInfos.setDateDebut(infosPro.getDateDebut());
//         newInfos.setStatut(1);
        
//         // ✅ ASSIGNATION SÉCURISÉE DU MANAGER
//         newInfos.setManager(managerPersiste); // Soit null, soit Manager persisté

//         System.out.println("Sauvegarde avec manager: " + (managerPersiste != null ? managerPersiste.getId() : "null"));
//         infosPro = infosProfessionnellesService.create(newInfos);
        
//     } catch (Exception e) {
//         System.err.println("Erreur lors de l'insertion intégrale de l'employé : " + e.getMessage());
//         e.printStackTrace();
//         throw e;
//     }
// }

    // public List<Employe> getAllManagers(){
        
    // }
}
