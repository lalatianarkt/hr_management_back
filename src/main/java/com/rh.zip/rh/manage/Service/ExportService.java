package com.rh.manage.Service;

import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import java.io.IOException;

import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.Style;
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.LineSeparator;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import com.rh.manage.Dto.EmployeInfosDTO;
import com.rh.manage.Model.Employe;
import com.rh.manage.Model.InfosProfessionnelles;

import jakarta.servlet.http.HttpServletResponse;

@Service
public class ExportService {
    @Autowired
    EmployeService employeService;

    public void exportEmployes(HttpServletResponse response) throws IOException {
        List<Employe> employes = employeService.findAllEmployeesActived();

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Employés");

        XSSFRow header = sheet.createRow(0);
        header.createCell(0).setCellValue("Nom");
        header.createCell(1).setCellValue("Prénom");
        header.createCell(2).setCellValue("Email");
        header.createCell(3).setCellValue("Téléphone");

        int rowIndex = 1;
        for (Employe e : employes) {
            XSSFRow row = sheet.createRow(rowIndex++);
            row.createCell(0).setCellValue(e.getNom());
            row.createCell(1).setCellValue(e.getPrenom());
            row.createCell(2).setCellValue(e.getEmail());
            row.createCell(3).setCellValue(e.getTelephone());
        }

        workbook.write(response.getOutputStream());
        workbook.close();
    }

    

    public void exportFicheEmploye(String idEmp, HttpServletResponse response) throws IOException {
    // Récupérer l'employé
    EmployeInfosDTO employe = employeService.getEmployeWithInfosById(idEmp);
    if (employe == null) {
        response.sendError(HttpServletResponse.SC_NOT_FOUND, "Employé non trouvé");
        return;
    }

    // Définir les headers de réponse pour téléchargement
    response.setContentType("application/pdf");
    response.setCharacterEncoding("UTF-8");
    String fileName = "Fiche_Employe_" + 
                     employe.getEmploye().getNom() + "_" + 
                     employe.getEmploye().getPrenom() + "_" + 
                     LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".pdf";
    response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

    // Créer le PDF avec format A4
    PdfWriter writer = new PdfWriter(response.getOutputStream());
    PdfDocument pdfDoc = new PdfDocument(writer);
    Document document = new Document(pdfDoc, PageSize.A4);
    document.setMargins(40, 40, 40, 40);
    
    // ========== STYLES AMÉLIORÉS ==========
    // Couleurs personnalisées
    DeviceRgb primaryColor = new DeviceRgb(41, 128, 185);      // Bleu professionnel
    DeviceRgb secondaryColor = new DeviceRgb(236, 240, 241);   // Gris clair
    DeviceRgb accentColor = new DeviceRgb(52, 152, 219);       // Bleu clair
    DeviceRgb successColor = new DeviceRgb(46, 204, 113);      // Vert
    DeviceRgb dangerColor = new DeviceRgb(231, 76, 60);        // Rouge
    DeviceRgb darkGray = new DeviceRgb(52, 73, 94);            // Gris foncé
    
    // Style pour le titre principal
    Style titleStyle = new Style()
            .setBold()
            .setFontSize(22)
            .setTextAlignment(TextAlignment.CENTER)
            .setFontColor(primaryColor)
            .setMarginBottom(10);
    
    // Style pour le sous-titre
    Style subtitleStyle = new Style()
            .setBold()
            .setFontSize(18)
            .setTextAlignment(TextAlignment.CENTER)
            .setFontColor(darkGray)
            .setMarginBottom(30);
    
    // Style pour les sections
    Style sectionStyle = new Style()
            .setBold()
            .setFontSize(15)
            .setMarginTop(25)
            .setMarginBottom(15)
            .setFontColor(primaryColor)
            .setPaddingLeft(10)
            .setBorderLeft(new SolidBorder(primaryColor, 4));
    
    // Style pour les en-têtes de cellule
    Style cellHeaderStyle = new Style()
            .setBold()
            .setFontSize(11)
            .setBackgroundColor(secondaryColor)
            .setPadding(10)
            .setBorder(new SolidBorder(ColorConstants.LIGHT_GRAY, 1))
            .setFontColor(darkGray);
    
    // Style pour le contenu des cellules
    Style cellContentStyle = new Style()
            .setFontSize(11)
            .setPadding(10)
            .setBorder(new SolidBorder(ColorConstants.LIGHT_GRAY, 1));
    
    // Style pour le statut actif
    Style activeStatusStyle = new Style()
            .setBold()
            .setFontSize(11)
            .setFontColor(successColor)
            .setPadding(10)
            .setBorder(new SolidBorder(ColorConstants.LIGHT_GRAY, 1))
            .setTextAlignment(TextAlignment.CENTER);
    
    // Style pour le statut inactif
    Style inactiveStatusStyle = new Style()
            .setBold()
            .setFontSize(11)
            .setFontColor(dangerColor)
            .setPadding(10)
            .setBorder(new SolidBorder(ColorConstants.LIGHT_GRAY, 1))
            .setTextAlignment(TextAlignment.CENTER);

    // ========== EN-TÊTE DU DOCUMENT ==========
    // Ligne de séparation décorative en haut
    document.add(new LineSeparator(new com.itextpdf.kernel.pdf.canvas.draw.SolidLine(2))
            .setStrokeColor(primaryColor)
            .setMarginBottom(20));
    
    // Titre principal
    Paragraph title = new Paragraph("FICHE INDIVIDUELLE DE L'EMPLOYÉ")
            .addStyle(titleStyle);
    document.add(title);
    
    // Nom complet de l'employé
    Paragraph subtitle = new Paragraph(
            employe.getEmploye().getNom().toUpperCase() + " " + 
            employe.getEmploye().getPrenom())
            .addStyle(subtitleStyle);
    document.add(subtitle);
    
    // Ligne d'information (ID et date)
    Paragraph infoLine = new Paragraph()
            .add("Référence: " + employe.getEmploye().getId())
            .add("  |  ")
            .add("Généré le: " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")))
            .setFontSize(9)
            .setFontColor(ColorConstants.GRAY)
            .setTextAlignment(TextAlignment.CENTER)
            .setMarginBottom(30);
    document.add(infoLine);

    // ========== INFORMATIONS PERSONNELLES ==========
    Paragraph persoTitle = new Paragraph("INFORMATIONS PERSONNELLES")
            .addStyle(sectionStyle);
    document.add(persoTitle);
    
    Table tablePerso = new Table(UnitValue.createPercentArray(new float[]{35, 65}))
            .useAllAvailableWidth()
            .setMarginBottom(20);
    
    addStyledCell(tablePerso, "ID", employe.getEmploye().getId(), cellHeaderStyle, cellContentStyle);
    addStyledCell(tablePerso, "Nom", employe.getEmploye().getNom(), cellHeaderStyle, cellContentStyle);
    addStyledCell(tablePerso, "Prénom", employe.getEmploye().getPrenom(), cellHeaderStyle, cellContentStyle);
    addStyledCell(tablePerso, "Date de naissance", 
            formatDate(employe.getEmploye().getDateNaissance()), cellHeaderStyle, cellContentStyle);
    addStyledCell(tablePerso, "Lieu de naissance", employe.getEmploye().getLieuNaissance(), cellHeaderStyle, cellContentStyle);
    addStyledCell(tablePerso, "Sexe", 
            employe.getEmploye().getSexe() != null ? employe.getEmploye().getSexe().getsexe() : "Non spécifié", 
            cellHeaderStyle, cellContentStyle);
    addStyledCell(tablePerso, "Nationalité", 
            employe.getEmploye().getNationalite() != null ? employe.getEmploye().getNationalite().getNationalite() : "Non spécifié", 
            cellHeaderStyle, cellContentStyle);
    addStyledCell(tablePerso, "Téléphone", employe.getEmploye().getTelephone(), cellHeaderStyle, cellContentStyle);
    addStyledCell(tablePerso, "Email", employe.getEmploye().getEmail(), cellHeaderStyle, cellContentStyle);
    addStyledCell(tablePerso, "CIN", employe.getEmploye().getCin(), cellHeaderStyle, cellContentStyle);
    addStyledCell(tablePerso, "Numéro CNaPS", 
            employe.getEmploye().getNumCnaps() != null ? employe.getEmploye().getNumCnaps() : "Non spécifié", 
            cellHeaderStyle, cellContentStyle);
    addStyledCell(tablePerso, "Situation familiale", 
        employe.getEmploye().getEtatCivil() != null ? 
        employe.getEmploye().getEtatCivil().getLibelle() : "Non spécifié", 
        cellHeaderStyle, cellContentStyle);
    addStyledCell(tablePerso, "Nombre d'enfants", 
            employe.getEmploye().getNbEnfants() != null ? 
            employe.getEmploye().getNbEnfants() + " enfant(s)" : "0 enfant", 
            cellHeaderStyle, cellContentStyle);
    addStyledCell(tablePerso, "Adresse", employe.getEmploye().getAdresse(), cellHeaderStyle, cellContentStyle);
    
    document.add(tablePerso);

    // ========== PARENTS ==========
    Paragraph parentsTitle = new Paragraph("INFORMATIONS FAMILIALES")
            .addStyle(sectionStyle);
    document.add(parentsTitle);
    
    Table tableParents = new Table(UnitValue.createPercentArray(new float[]{35, 65}))
            .useAllAvailableWidth()
            .setMarginBottom(20);
    
    addStyledCell(tableParents, "Nom du père", 
            employe.getEmploye().getNomPere() != null ? employe.getEmploye().getNomPere() : "Non spécifié", 
            cellHeaderStyle, cellContentStyle);
    addStyledCell(tableParents, "Nom de la mère", 
            employe.getEmploye().getNomMere() != null ? employe.getEmploye().getNomMere() : "Non spécifié", 
            cellHeaderStyle, cellContentStyle);
    
    document.add(tableParents);

    // ========== INFORMATIONS PROFESSIONNELLES ==========
    if(employe.getInfosProfessionnelles() != null && !employe.getInfosProfessionnelles().isEmpty()){
        Paragraph proTitle = new Paragraph("INFORMATIONS PROFESSIONNELLES")
                .addStyle(sectionStyle);
        document.add(proTitle);
        
        for (int i = 0; i < employe.getInfosProfessionnelles().size(); i++) {
            InfosProfessionnelles infoPro = employe.getInfosProfessionnelles().get(i);
            
            // Indicateur pour situations multiples
            if (employe.getInfosProfessionnelles().size() > 1) {
                Paragraph situationNumber = new Paragraph("Situation " + (i + 1))
                        .setBold()
                        .setFontSize(12)
                        .setFontColor(accentColor)
                        .setMarginBottom(10);
                document.add(situationNumber);
            }
            
            Table tableInfosPro = new Table(UnitValue.createPercentArray(new float[]{35, 65}))
                    .useAllAvailableWidth()
                    .setMarginBottom(20);
            
            addStyledCell(tableInfosPro, "Matricule", infoPro.getMatricule(), cellHeaderStyle, cellContentStyle);
            addStyledCell(tableInfosPro, "Poste", 
                    infoPro.getPoste() != null ? infoPro.getPoste().getNom() : "Non spécifié", 
                    cellHeaderStyle, cellContentStyle);
            addStyledCell(tableInfosPro, "Département", 
                    infoPro.getPoste() != null && infoPro.getPoste().getDepartement() != null ? 
                    infoPro.getPoste().getDepartement().getNom() : "Non spécifié", 
                    cellHeaderStyle, cellContentStyle);
            addStyledCell(tableInfosPro, "Date d'embauche", 
                    formatDate(infoPro.getDateEmbauche()), cellHeaderStyle, cellContentStyle);
            addStyledCell(tableInfosPro, "Date de fin", 
                    formatDate(infoPro.getDateDebauche()), cellHeaderStyle, cellContentStyle);
            
            // Statut avec style conditionnel
            if (infoPro.getStatut() != -1) {
                String statutText = infoPro.getStatut() == 0 ? "ACTIF" : "INACTIF";
                Style statusStyle = infoPro.getStatut() == 0 ? activeStatusStyle : inactiveStatusStyle;
                
                Cell statusHeaderCell = new Cell()
                        .add(new Paragraph("Statut")
                                .addStyle(cellHeaderStyle));
                Cell statusContentCell = new Cell()
                        .add(new Paragraph(statutText)
                                .addStyle(statusStyle));
                
                tableInfosPro.addCell(statusHeaderCell);
                tableInfosPro.addCell(statusContentCell);
            } else {
                addStyledCell(tableInfosPro, "Statut", "Non spécifié", cellHeaderStyle, cellContentStyle);
            }
            
            addStyledCell(tableInfosPro, "Salaire de base", 
                    formatCurrency(infoPro.getSalaireBase()), cellHeaderStyle, cellContentStyle);
            
            document.add(tableInfosPro);
            
            // Ligne de séparation entre les situations professionnelles
            if (i < employe.getInfosProfessionnelles().size() - 1) {
                document.add(new LineSeparator(new com.itextpdf.kernel.pdf.canvas.draw.SolidLine(0.5f))
                        .setStrokeColor(ColorConstants.LIGHT_GRAY)
                        .setMarginTop(10)
                        .setMarginBottom(10));
            }
        }
    } else {
        Paragraph noProInfo = new Paragraph("Aucune information professionnelle disponible")
                .setItalic()
                .setFontColor(ColorConstants.GRAY)
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(20);
        document.add(noProInfo);
    }

    // ========== CONTACT D'URGENCE ==========
    if (employe.getEmploye().getEmergencyContact() != null) {
        Paragraph emergencyTitle = new Paragraph("CONTACT D'URGENCE")
                .addStyle(sectionStyle);
        document.add(emergencyTitle);
        
        Table tableUrgence = new Table(UnitValue.createPercentArray(new float[]{35, 65}))
                .useAllAvailableWidth()
                .setMarginBottom(20);
        
        addStyledCell(tableUrgence, "Nom", 
                employe.getEmploye().getEmergencyContact().getNom(), cellHeaderStyle, cellContentStyle);
        addStyledCell(tableUrgence, "Téléphone", 
                employe.getEmploye().getEmergencyContact().getContact(), cellHeaderStyle, cellContentStyle);
        
        if (employe.getEmploye().getEmergencyContact().getEmail() != null) {
            addStyledCell(tableUrgence, "Email", 
                    employe.getEmploye().getEmergencyContact().getEmail(), cellHeaderStyle, cellContentStyle);
        }
        
        addStyledCell(tableUrgence, "Adresse", 
                employe.getEmploye().getEmergencyContact().getAdresse(), cellHeaderStyle, cellContentStyle);
        
        document.add(tableUrgence);
    }

    // ========== PIED DE PAGE AMÉLIORÉ ==========
    // Ligne de séparation avant le pied de page
    document.add(new LineSeparator(new com.itextpdf.kernel.pdf.canvas.draw.SolidLine(1))
            .setStrokeColor(primaryColor)
            .setMarginTop(40));
    
    Paragraph footer = new Paragraph()
            .setFontSize(9)
            .setFontColor(darkGray)
            .setTextAlignment(TextAlignment.CENTER)
            .setMarginTop(15);
    
    footer.add("Document confidentiel • ")
          .add("Système de Gestion RH • ")
          .add("Page 1/1 • ")
          .add("Généré le " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy à HH:mm")));
    
    document.add(footer);

    document.close();
}

// Méthode utilitaire pour ajouter des cellules avec style
private void addStyledCell(Table table, String header, String content, Style headerStyle, Style contentStyle) {
    Cell headerCell = new Cell().add(new Paragraph(header)).addStyle(headerStyle);
    Cell contentCell = new Cell().add(new Paragraph(content != null ? content : "Non spécifié")).addStyle(contentStyle);
    table.addCell(headerCell);
    table.addCell(contentCell);
}

// Méthode utilitaire pour formater les dates
private String formatDate(LocalDate date) {
    if (date == null) {
        return "Non spécifié";
    }
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    return date.format(formatter);
}

// Méthode utilitaire pour formater les montants
private String formatCurrency(Double amount) {
    if (amount == null) {
        return "Non spécifié";
    }
    DecimalFormat formatter = new DecimalFormat("#,##0.00 MGA");
    return formatter.format(amount);
}


}
