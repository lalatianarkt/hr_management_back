package com.rh.manage.Repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.rh.manage.Model.Employe;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeRepository extends JpaRepository<Employe, String> {
    Optional<Employe> findByEmail(String email);

    // Récupérer tous les employés avec statut = 0
    List<Employe> findByStatut(int statut);
    
    // Récupérer un employé par ID avec statut = 0
    Optional<Employe> findByIdAndStatut(String id, int statut);

    // Alternative avec paramètre
    @Query("SELECT e FROM Employe e WHERE e.statut = :statut ORDER BY e.nom ASC, e.prenom ASC")
    List<Employe> findAllEmployeesByStatusSorted(int statut);

    // NOUVELLE : Version paginée
    @Query("SELECT e FROM Employe e WHERE e.statut = :statut ORDER BY e.nom, e.prenom")
    Page<Employe> findAllEmployeesByStatusSorted(
        @Param("statut") int statut, 
        Pageable pageable
    );

    // OU version plus simple sans paramètre de statut
    @Query("SELECT e FROM Employe e WHERE e.statut = 0 ORDER BY e.nom, e.prenom")
    Page<Employe> findAllActiveEmployeesSorted(Pageable pageable);

}

