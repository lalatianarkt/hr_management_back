package com.rh.manage.Repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.rh.manage.Model.Paie;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

// Faites-moi une page en jsx qui affiche la liste des départements avec le statut paie et période de paie sous forme de tableau biensûr, 
// puis la masse salariale des salaires de base par département si voici le lien pour départements : http://localhost:8080/api/departements

@Repository
public interface PaieRepository extends JpaRepository<Paie, String> {
    
    // Recherche par matricule
    List<Paie> findByMatricule(Integer matricule);
    
    // Recherche par nom
    List<Paie> findByNomContainingIgnoreCase(String nom);
    
    // Recherche par prénom
    List<Paie> findByPrenomContainingIgnoreCase(String prenom);
    
    // Recherche par nom complet
    List<Paie> findByNomContainingIgnoreCaseOrPrenomContainingIgnoreCase(String nom, String prenom);
    
    // Recherche par période
    List<Paie> findByDateDebutPeriodeBetween(LocalDate dateDebut, LocalDate dateFin);
    
    // Recherche par mois/année
//     List<Paie> findByDateDebutPeriodeYearAndDateDebutPeriodeMonth(int year, int month);
    
    // Recherche par statut de clôture
    List<Paie> findByStatutCloture(Integer statutCloture);
    
    // Recherche par employé
    List<Paie> findByEmployeId(String employeId);

    @Query("SELECT p FROM Paie p WHERE p.employe.id = :employeId AND p.statutCloture = 0 ORDER BY p.dateFinPeriode DESC")
    Optional<Paie> findDernierePaieNonCloturee(@Param("employeId") String employeId);

    boolean existsByEmployeIdAndStatutCloture(String employeId, Integer statutCloture);
    
    // Recherche par département
    List<Paie> findByDepartement(String departement);

    // Recherche par mois/année - CORRECTION ICI
    @Query("SELECT p FROM Paie p WHERE YEAR(p.dateDebutPeriode) = :year AND MONTH(p.dateDebutPeriode) = :month")
    List<Paie> findByDateDebutPeriodeYearAndMonth(@Param("year") int year, @Param("month") int month);
    
    // Recherche paginée avec filtre
    @Query("SELECT p FROM Paie p WHERE " +
           "(:matricule IS NULL OR p.matricule = :matricule) AND " +
           "(:nom IS NULL OR LOWER(p.nom) LIKE LOWER(CONCAT('%', :nom, '%'))) AND " +
           "(:prenom IS NULL OR LOWER(p.prenom) LIKE LOWER(CONCAT('%', :prenom, '%'))) AND " +
           "(:dateDebut IS NULL OR p.dateDebutPeriode >= :dateDebut) AND " +
           "(:dateFin IS NULL OR p.dateFinPeriode <= :dateFin) AND " +
           "(:statutCloture IS NULL OR p.statutCloture = :statutCloture)")
    Page<Paie> searchPaies(
            @Param("matricule") Integer matricule,
            @Param("nom") String nom,
            @Param("prenom") String prenom,
            @Param("dateDebut") LocalDate dateDebut,
            @Param("dateFin") LocalDate dateFin,
            @Param("statutCloture") Integer statutCloture,
            Pageable pageable);
    
    // Vérifier si une paie existe pour un employé dans une période
    boolean existsByEmployeIdAndDateDebutPeriodeAndDateFinPeriode(
            String employeId, LocalDate dateDebut, LocalDate dateFin);
    
    // Récupérer la dernière paie d'un employé
    Optional<Paie> findFirstByEmployeIdOrderByDateFinPeriodeDesc(String employeId);
    
    // Statistiques
    @Query("SELECT COUNT(p) FROM Paie p WHERE p.dateDebutPeriode >= :dateDebut AND p.dateFinPeriode <= :dateFin")
    long countByPeriode(@Param("dateDebut") LocalDate dateDebut, @Param("dateFin") LocalDate dateFin);
    
    @Query("SELECT COALESCE(SUM(p.salaireBase), 0) FROM Paie p WHERE p.dateDebutPeriode >= :dateDebut AND p.dateFinPeriode <= :dateFin")
    BigDecimal sumSalaireBaseByPeriode(@Param("dateDebut") LocalDate dateDebut, @Param("dateFin") LocalDate dateFin);
    
    // Liste des paies avec détails employé
    @Query("SELECT p FROM Paie p JOIN FETCH p.employe WHERE p.id = :id")
    Optional<Paie> findByIdWithEmploye(@Param("id") String id);
    
    // Liste des paies pour une société
    List<Paie> findByInformationSocieteId(Integer infoSocieteId);

    @Query("SELECT DISTINCT p.dateDebutPeriode FROM Paie p WHERE p.departement = :departement AND p.statutCloture = 0 ORDER BY p.dateDebutPeriode DESC")
    Optional<LocalDate> findDistinctDateDebutPeriodeByDepartementAndStatutClotureZero(@Param("departement") String departement);
}
