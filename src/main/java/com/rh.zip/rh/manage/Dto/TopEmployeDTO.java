package com.rh.manage.Dto;

import com.rh.manage.Model.DemandeConge;

public class TopEmployeDTO {
    DemandeConge demandeConge;
    double moyenne;
    
    public DemandeConge getDemandeConge() {
        return demandeConge;
    }
    public void setDemandeConge(DemandeConge demandeConge) {
        this.demandeConge = demandeConge;
    }
    public double getMoyenne() {
        return moyenne;
    }
    public void setMoyenne(double moyenne) {
        this.moyenne = moyenne;
    }

    
}
