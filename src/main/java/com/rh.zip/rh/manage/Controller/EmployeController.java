package com.rh.manage.Controller;

import com.rh.manage.Dto.EmployeDTO;
import com.rh.manage.Dto.EmployeInfosDTO;
import com.rh.manage.Dto.StatAllInfoDTO;
import com.rh.manage.Model.Employe;
import com.rh.manage.Model.InfosProfessionnelles;
import com.rh.manage.Service.AutomatisationService;
import com.rh.manage.Service.DepartementService;
import com.rh.manage.Service.EmployeService;
import com.rh.manage.Service.InfosProfessionnellesService;
import com.rh.manage.Service.StatAllInfoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.*;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/employes")
public class EmployeController {
    @Autowired
    private StatAllInfoService statAllInfoService; 

    @Autowired
    private EmployeService employeService;

    @Autowired
    private DepartementService departementService;

    @Autowired
    private InfosProfessionnellesService infosProfessionnellesService;

    @Autowired
    private AutomatisationService automatisationService;

    // @GetMapping("/getManager")
    // public ResponseEntity<List<Employe>> getAllManagers() {
    //     return ResponseEntity.ok(employeService.getAllManagers());
    // }
    

    // 🔹 Récupérer tous les employés
    // @GetMapping
    // public ResponseEntity<List<Employe>> getAllEmployes() {
    //     System.out.println("All emp " + employeService.getAll());
    //     return ResponseEntity.ok(employeService.getAll());
    // } 



    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable String id, @RequestBody Employe employe) {
        try {
            // Vérifier que l'ID dans le path correspond à l'ID dans l'objet employé (optionnel mais recommandé)
            // if (!id.equals(employe.getId())) {
            //     return ResponseEntity.badRequest().body("L'ID dans l'URL ne correspond pas à l'ID de l'employé");
            // }
                        
            Employe updatedEmploye = employeService.update_emp(employe, id);
            return ResponseEntity.ok(updatedEmploye);    
        } catch (Exception e) {
            System.out.println("Erreur lors de la modification de l'employé: " + e.getMessage());
            e.printStackTrace(); // Ajouter stack trace pour plus de détails
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erreur lors de la modification de l'employé: " + e.getMessage());
        }
    }

    @GetMapping("/allEmpActives")
    public ResponseEntity<?> getAllEmployeesActived() {
        try {
            return ResponseEntity.ok(employeService.findAllEmployeesActived());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erreur lors de la récupération des employés: " + e.getMessage());
        }
    }
    
    @GetMapping("/allEmpWithInfos")
    public ResponseEntity<Map<String, Object>> getAllEmpWithInfos(
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "10") int size,
        @RequestParam(defaultValue = "nom") String sortBy,
        @RequestParam(defaultValue = "asc") String direction) {
        
        try {
            // 1. Récupérer les statistiques (inchangé)
            StatAllInfoDTO stat = statAllInfoService.getAllStatistiques();
            
            // 2. Récupérer les employés avec pagination
            Page<EmployeInfosDTO> employesPage = employeService.getAllEmployesWithInfos(
                page, size, sortBy, direction
            );
            
            // 3. Construire la réponse
            Map<String, Object> response = new HashMap<>();
            response.put("statistiques", stat);
            response.put("employes", employesPage.getContent());
            response.put("currentPage", employesPage.getNumber());
            response.put("totalItems", employesPage.getTotalElements());
            response.put("totalPages", employesPage.getTotalPages());
            response.put("pageSize", employesPage.getSize());
            response.put("hasNext", employesPage.hasNext());
            response.put("hasPrevious", employesPage.hasPrevious());
            response.put("totalEmployes", employesPage.getTotalElements());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            System.err.println("Erreur lors de la récupération des employés: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping
    public ResponseEntity<List<Employe>> getAllEmployes() {
        try {
            List<Employe> employes = employeService.getAll();
            return ResponseEntity.ok(employes);
        } catch (Exception e) {
            System.err.println("Erreur lors de la récupération des employés: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getEmployeById(@PathVariable String id) {
        try {

            EmployeInfosDTO emp = employeService.getEmployeWithInfosById(id);
            // Optional<Employe> employeOpt = employeService.getById(id);
            
            if (emp != null) {
            //     Employe employe = employeOpt.get();
                
            //     // Récupérer InfosProfessionnelles par idEmploye
            //     Optional<InfosProfessionnelles> infosProOpt = infosProfessionnellesService.getById(id);
                
            //     // Créer le DTO
            //     EmployeInfosDTO employeInfosDTO = new EmployeInfosDTO();
            //     employeInfosDTO.setEmploye(employe);
            //     employeInfosDTO.setInfosProfessionnelles(infosProOpt.orElse(null));
                
            //     System.out.println("Employé trouvé: " + employe.getId());
                return ResponseEntity.ok(emp);
            } else {
                System.out.println("Employé non trouvé: " + id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employé non trouvé");
            }
        } catch (Exception e) {
            System.err.println("Erreur lors de la récupération de l'employé " + id + ": " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erreur lors de la récupération de l'employé");
        }
    }

    // 🔹 Récupérer un employé par ID
    // @GetMapping("/{id}")
    // public ResponseEntity<?> getEmployeById(@PathVariable String id) {
    //     Optional<Employe> employeOpt = employeService.getById(id);
    //     // System.out.println("emp : " + employeOpt.get().getId());
    //     if (employeOpt.isPresent()) { 
    //         return ResponseEntity.ok(employeOpt.get());
    //     } else {
    //         return ResponseEntity.status(404).body("Employé non trouvé");
    //     }
    // }

    // 🔹 Récupérer un employé par email
    @GetMapping("/email/{email}")
    public ResponseEntity<?> getEmployeByEmail(@PathVariable String email) {
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++email " + email);
        Optional<Employe> employeOpt = employeService.getByEmail(email);
        Employe emp = employeOpt.get();
        if(emp != null){
            System.out.println("emp " + emp.getEmail());
        }
        if (employeOpt.isPresent()) {
            return ResponseEntity.ok(employeOpt.get());
        } else {
            return ResponseEntity.status(404).body("Employé non trouvé");
        }
    }

    @PostMapping
    public ResponseEntity<?> saveEmploye(@RequestBody EmployeDTO employeDTO) {
        try {

            // System.out.println("ato++++++++++++++++++++++++++++++++++++++++++++++");
            // employeDTO.getEmergencyContact().getCreatedAt();
            // employeDTO.getEmergencyContact().getAdresse();

        //    System.out.println("nationalite : " + employeDTO.getNationalite().getId());
        //    System.out.println("date début : " + employeDTO.getInfosProfessionnelles().getDateDebutAssignationPoste());
        //    System.out.println("contact 2323 " + employeDTO.getEmergencyContact().getContact());
        //    System.out.println("manager : " + employeDTO.getInfosProfessionnelles().getManager());
            // System.out.println("lala" + employeDTO.getEmergencyContact().getAdresse());     
            Employe emp = employeService.insertionIntegraleEmploye(employeDTO);
            // automatisationService.sendMailDeBienvenueAutomatique(emp);
            return ResponseEntity.ok("Employé enregistré avec succès");
        } catch (DataAccessException e) {
            System.out.println("erreur : ++++++++++++++++++++++++++++++++++++++++++++++++ : " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erreur lors de l'enregistrement de l'employé : problème d'accès aux données");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest()
                    .body("Données employé invalides : " + e.getMessage());
        } 
        // catch(HttpMessageNotReadableException e){
        //     e.printStackTrace();
        //     System.out.println("erreur de conversion : " + e.getMessage());
        //     return ResponseEntity.badRequest()
        //             .body("Erreur de conversion en JSON : " + e.getMessage());
        // }
        
        catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erreur inattendue : " + e.getMessage());
        }
    }

    // @GetMapping("/{id}/infos-professionnelles")
    // public String getMethodName(@RequestParam String param) {
    //     return new String();
    // }
    
    // Endpoint pour récupérer les employés actifs
    @GetMapping("/actifs")
    public ResponseEntity<List<Employe>> getEmployesActifs() {
        try {
            List<Employe> employesActifs = employeService.getEmployesActifs();
            return ResponseEntity.ok(employesActifs);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    // Endpoint pour récupérer les infos professionnelles avec statut = 0 d'un employé
    @GetMapping("/{employeId}/infos-professionnelles")
    public ResponseEntity<?> getInfosProfessionnellesByEmployeId(@PathVariable String employeId) {
        try {
            List<InfosProfessionnelles> infos = employeService.getInfosProfessionnellesByEmployeId(employeId);
            
            // if (infos.isEmpty()) {
            //     return ResponseEntity.noContent().build();
            // }
            
            return ResponseEntity.ok(infos);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
    
    // Endpoint pour récupérer la dernière info professionnelle avec statut = 0 d'un employé
    @GetMapping("/{employeId}/derniere-info-professionnelle")
    public ResponseEntity<InfosProfessionnelles> getDerniereInfoProfessionnelleByEmployeId(@PathVariable String employeId) {
        try {
            Optional<InfosProfessionnelles> info = employeService.getDerniereInfoProfessionnelleByEmployeId(employeId);
            
            if (info.isPresent()) {
                return ResponseEntity.ok(info.get());
            } else {
                return ResponseEntity.noContent().build();
            }
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
    
    // Endpoint pour récupérer une info professionnelle avec statut = 0 d'un employé
    @GetMapping("/{employeId}/info-professionnelle")
    public ResponseEntity<?> getInfoProfessionnelleByEmployeId(@PathVariable String employeId) {
        try {
            List<InfosProfessionnelles> info = employeService.getInfoProfessionnelleByEmployeId(employeId);
            if (info.size() != 0 && info.size() > 0) {
                return ResponseEntity.ok(info);
            } else {
                return ResponseEntity.noContent().build();
            }
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
    

}
