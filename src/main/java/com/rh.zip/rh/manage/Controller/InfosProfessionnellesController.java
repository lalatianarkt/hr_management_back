package com.rh.manage.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.rh.manage.Model.InfosAdministratives;
import com.rh.manage.Model.InfosProfessionnelles;
import com.rh.manage.Model.Manager;
import com.rh.manage.Model.Token;
import com.rh.manage.Service.InfosProfessionnellesService;
import com.rh.manage.Service.ManagerService;
import com.rh.manage.Service.TokenService;
import com.rh.manage.Service.UserService;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/api/infosPro")
@CrossOrigin(origins = "*")
public class InfosProfessionnellesController { 
    @Autowired
    private InfosProfessionnellesService infosProService;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private ManagerService managerService;

    // ✅ Réponse standardisée
    private ResponseEntity<Map<String, Object>> createResponse(Object data, String message, HttpStatus status) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", status == HttpStatus.OK || status == HttpStatus.CREATED);
        response.put("message", message);
        response.put("data", data);
        return new ResponseEntity<>(response, status);
    }

    @GetMapping("/infosEmp/{id}")
    public ResponseEntity<?> getInfosProfessionnellesByEmployeId(@PathVariable String id) {
        try {
            // Validation de l'ID
            if (id == null || id.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                    .body(Map.of(
                        "status", 400,
                        "message", "L'ID de l'employé est requis",
                        "timestamp", LocalDateTime.now()
                    ));
            }

            // Récupération des informations professionnelles
            InfosProfessionnelles infosPro = infosProService.findInfosProfessionnellesByIdEmploye(id);
            
            // Vérification si des infos pro existent
            if (infosPro == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of(
                        "status", 404,
                        "message", "Aucune information professionnelle trouvée pour l'employé ID: " + id,
                        "timestamp", LocalDateTime.now()
                    ));
            }

            // Réponse avec les données
            return ResponseEntity.ok(Map.of(
                "status", 200,
                "message", "Informations professionnelles récupérées avec succès",
                "data", infosPro,
                "timestamp", LocalDateTime.now()
            ));
            
        } catch (DataAccessException e) {
            // Erreur d'accès à la base de données
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of(
                    "status", 500,
                    "message", "Erreur d'accès à la base de données",
                    "error", e.getMessage(),
                    "timestamp", LocalDateTime.now()
                ));
                
        } catch (IllegalArgumentException e) {
            // Erreur de validation
            return ResponseEntity.badRequest()
                .body(Map.of(
                    "status", 400,
                    "message", "Paramètre invalide",
                    "error", e.getMessage(),
                    "timestamp", LocalDateTime.now()
                ));
                
        } catch (Exception e) {
            // Erreur inattendue
            // log.error("Erreur inattendue dans getInfosProfessionnellesByEmployeId pour l'ID: " + id, e);
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of(
                    "status", 500,
                    "message", "Une erreur interne est survenue",
                    "error", e.getMessage(),
                    "timestamp", LocalDateTime.now()
                ));
        }
    }
    

    @GetMapping("/manager/dep")
    public ResponseEntity<?> getDepManager(@RequestBody Manager manager){
        try {
            InfosProfessionnelles infosPro = infosProService.getDepartementActuel(manager);
            return ResponseEntity.ok(infosPro);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Erreur pendant la récupération de département de managerId :" + manager.getId());
        }
    }

    @GetMapping("/manager/emp")
    public ResponseEntity<?> getEmpParManager(@RequestHeader("Authorization") String authHeader) {
        try {
            // 1. Validation du header Authorization
            if (authHeader == null || authHeader.trim().isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("En-tête Authorization manquant");
            }
            
            // 2. Extraction du token
            String token;
            if (authHeader.startsWith("Bearer ")) {
                token = authHeader.substring(7).trim();
            } else {
                token = authHeader.trim();
            }
            
            // 3. Validation du token
            if (token.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Token manquant ou vide");
            }
            
            // 4. Récupération du token en base
            Token tokenUser = tokenService.getTokenByToken(token);
            if (tokenUser == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Token invalide");
            }
            
            // 5. Récupération des informations professionnelles
            List<InfosProfessionnelles> les_infos = managerService.findAllInfosParManagerParToken(tokenUser);
            
            // 6. Retour direct des données
            return ResponseEntity.ok(les_infos);
            
        } catch (Exception e) {
            // Log l'erreur (à implémenter avec un logger)
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("Erreur serveur: " + e.getMessage());
        }
    }

    // @GetMapping("/check-matricule/{matricule}")
    // public boolean checkMatricule(@PathVariable String matricule) {
    //     return infosProService.isMatriculeExists(matricule);
    // }

    // === CREATE ===
    @PostMapping
    public ResponseEntity<?> createInfosPro(@RequestBody InfosProfessionnelles infosPro) {
        try {
            InfosProfessionnelles savedInfosPro = infosProService.create(infosPro);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedInfosPro);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Erreur lors de la création: " + e.getMessage());
        }
    }

    @GetMapping("/allEmpNotAssignedToManager")
    public ResponseEntity<List<InfosProfessionnelles>> getAllInfosProWithoutManager() {
        List<InfosProfessionnelles> infosProList = infosProService.getInfoProForNonManagers();
        return ResponseEntity.ok(infosProList);
    }   
    
    // === READ ALL ===
    @GetMapping
    public ResponseEntity<List<InfosProfessionnelles>> getAllInfosPro() {
        List<InfosProfessionnelles> infosProList = infosProService.getAll();
        return ResponseEntity.ok(infosProList);
    }

    // === READ BY ID ===
    @GetMapping("/{id}")
    public ResponseEntity<?> getInfosProById(@PathVariable String id) {
        try {
            InfosProfessionnelles infosPro = infosProService.getById(id).get();
            return ResponseEntity.ok(infosPro);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Infos professionnelles non trouvées pour l'ID: " + id);
        }
    }

    // === changement de département de l'employé ===
    @PostMapping("/changeDep")
    public ResponseEntity<?> updateInfosPro(@RequestBody InfosProfessionnelles infosPro, @PathVariable String idEmp) {
        try {
            InfosProfessionnelles infoProActuel = infosProService.getByIdEmploye(idEmp).get();
            // infoProActuel.setDepartement(infosPro.getDepartement());
            InfosProfessionnelles updatedInfosPro = infosProService.update(infoProActuel);
            return ResponseEntity.ok(updatedInfosPro); 
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Erreur lors de la mise à jour: " + e.getMessage());
        }
    }

    // === DELETE ===
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteInfosPro(@PathVariable String id) {
        try {
            infosProService.deleteById(id);
            return ResponseEntity.ok("Infos professionnelles supprimées avec succès");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Erreur lors de la suppression: " + e.getMessage());
        }
    } 

    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updateInfoPro(@PathVariable String id, @RequestBody InfosProfessionnelles infosProfessionnelles) {
        try {
            // Forcer l'ID depuis le path pour éviter les incohérences
            infosProfessionnelles.setId(id);
            InfosProfessionnelles infosPro = infosProService.update_info_pro(infosProfessionnelles, id);
            return createResponse(infosPro, "Information professionnelle modifiée avec succès", HttpStatus.OK);
        } catch (RuntimeException e) {
            return createResponse(null, e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return createResponse(null, "Erreur modification: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/emp/{id}")
    public ResponseEntity<?> getEmployeInfos(@PathVariable String id) {
        try {
            return ResponseEntity.ok(infosProService.getInfosProfessionnellesByEmployeId(id));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Erreur lors de la récupération des infos pros: " + e.getMessage());
        }
    }

    // @GetMapping("/emp/")
    // public String getMethodName(@RequestParam String param) {
    //     return new String();
    // }
    
    
}