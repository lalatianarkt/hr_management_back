package com.rh.manage.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.rh.manage.Model.Employe;
import com.rh.manage.Model.MouvementSolde;
import com.rh.manage.Model.TypeEnumConge;
import com.rh.manage.Service.EmployeService;
import com.rh.manage.Service.MouvementSoldeService;

import java.util.List;

@RestController
@RequestMapping("/api/mouvementSolde")
public class MouvementSoldeController {

    private final MouvementSoldeService service;

    @Autowired
    EmployeService employeService;

    public MouvementSoldeController(MouvementSoldeService service) {
        this.service = service;
    }

    @GetMapping
    public List<MouvementSolde> getAll() {
        return service.getAllMouvements();
    }

    @GetMapping("/{id}")
    public ResponseEntity<MouvementSolde> getById(@PathVariable int id) {
        return service.getMouvementById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/employe/{idEmploye}/solde-actuel")
    public MouvementSolde getByEmploye(@PathVariable String idEmploye) {
        Employe employe = employeService.getById(idEmploye).get();
        return service.getDernierMouvementParEmploye(employe);
    }   

    @GetMapping("/type/{typeMouvement}")
    public List<MouvementSolde> getByType(@PathVariable TypeEnumConge typeMouvement) {
        return service.getMouvementsByType(typeMouvement);
    }

    @PostMapping
    public MouvementSolde create(@RequestBody MouvementSolde mouvement) {
        return service.saveMouvement(mouvement);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MouvementSolde> update(@PathVariable int id, @RequestBody MouvementSolde mouvement) {
        return service.getMouvementById(id).map(existing -> {
            mouvement.setId(id);
            return ResponseEntity.ok(service.saveMouvement(mouvement));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        service.deleteMouvement(id);
        return ResponseEntity.noContent().build();
    }
}


