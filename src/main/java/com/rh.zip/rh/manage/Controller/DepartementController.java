package com.rh.manage.Controller;

import com.rh.manage.Model.Departement;
import com.rh.manage.Model.Poste;
import com.rh.manage.Service.DepartementService;
import com.rh.manage.Service.PosteService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/api/departements")
@CrossOrigin(origins = "*") // permet les requêtes depuis le front (React, etc.)
public class DepartementController {

    @Autowired
    private PosteService posteService;

    @Autowired
    private DepartementService departementService;

    @GetMapping("/actif")
    public ResponseEntity<?> getAllDepartementsActifs(){
        return ResponseEntity.ok(departementService.getDepartementActif());
    }
    
    // ✅ 1. Ajouter un département
    @PostMapping
    public ResponseEntity<Departement> createDepartement(@RequestBody Departement departement) {
        Departement newDepartement = departementService.saveDepartement(departement);
        return ResponseEntity.ok(newDepartement);
    }

    // ✅ 2. Récupérer tous les départements
    @GetMapping
    public ResponseEntity<List<Departement>> getAllDepartements() {
        List<Departement> departements = departementService.getAllDepartements();
        return ResponseEntity.ok(departements);
    }

    // ✅ 3. Récupérer un département par ID
    @GetMapping("/{id}")
    public ResponseEntity<Departement> getDepartementById(@PathVariable String id) {
        Optional<Departement> departement = departementService.getDepartementById(id);
        return departement.map(ResponseEntity::ok)
                          .orElse(ResponseEntity.notFound().build());
    }

    // ✅ 4. Mettre à jour un département
    @PutMapping("/{id}")
    public ResponseEntity<Departement> updateDepartement(@PathVariable String id, @RequestBody Departement updatedDepartement) {
        Optional<Departement> existing = departementService.getDepartementById(id);
        if (existing.isPresent()) {
            Departement departement = existing.get();
            departement.setNom(updatedDepartement.getNom());
            departement.setDescription(updatedDepartement.getDescription());
            departement.setModifiedAt(updatedDepartement.getModifiedAt());
            Departement saved = departementService.saveDepartement(departement);
            return ResponseEntity.ok(saved);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // ✅ 5. Supprimer un département
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDepartement(@PathVariable String id) {
        departementService.deleteDepartement(id);
        return ResponseEntity.noContent().build();
    }

    // ✅ 6. Rechercher un département par nom
    @GetMapping("/nom/{nom}")
    public ResponseEntity<Departement> getDepartementByNom(@PathVariable String nom) {
        Departement departement = departementService.getDepartementByNom(nom);
        if (departement != null) {
            return ResponseEntity.ok(departement);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/{departementId}/postes")
    public ResponseEntity<List<Poste>> getPostesByDepartement(@PathVariable String departementId) {
        try {
            List<Poste> postes = posteService.getPostesByDepartementId(departementId);
            
            if (postes.isEmpty()) {
                return ResponseEntity.noContent().build(); // 204 No Content
            }
            
            return ResponseEntity.ok(postes); // 200 OK
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build(); // 400 Bad Request
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build(); // 500 Internal Server Error
        }
    }
    
}
