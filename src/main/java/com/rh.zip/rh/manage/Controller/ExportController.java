package com.rh.manage.Controller;

import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rh.manage.Model.Employe;
import com.rh.manage.Service.EmployeService;
import com.rh.manage.Service.ExportService;

import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/export/employes")
public class ExportController {
    @Autowired
    ExportService exportService;

    @Autowired
    EmployeService employeService;

    @GetMapping
    public void exportEmployes(HttpServletResponse response) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=employes.xlsx");

        List<Employe> employes = employeService.findAllEmployeesActived();

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Employés");

        Row header = sheet.createRow(0);
        header.createCell(0).setCellValue("Nom");
        header.createCell(1).setCellValue("Prénom");
        header.createCell(2).setCellValue("Email");
        header.createCell(3).setCellValue("Téléphone");

        int rowIndex = 1;
        for (Employe e : employes) {
            Row row = sheet.createRow(rowIndex++);
            row.createCell(0).setCellValue(e.getNom());
            row.createCell(1).setCellValue(e.getPrenom());
            row.createCell(2).setCellValue(e.getEmail());
            row.createCell(3).setCellValue(e.getTelephone());
        }

        workbook.write(response.getOutputStream());
        workbook.close();
    }


    @GetMapping("/{id}")
    public ResponseEntity<?> exportFicheEmployeEnPdf(
            @PathVariable("id") String idEmp,
            HttpServletResponse response) throws IOException {

        try {
            exportService.exportFicheEmploye(idEmp, response);
            return ResponseEntity.ok().build();

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erreur lors de l'export: " + e.getMessage());
        }
    }

}
